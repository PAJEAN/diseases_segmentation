1738 diseases, occurrences >= 1, specificity to disease-level.
